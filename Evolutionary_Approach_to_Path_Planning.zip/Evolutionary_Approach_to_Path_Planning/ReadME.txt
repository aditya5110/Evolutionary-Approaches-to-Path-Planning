=====================MAJOR II(2023) PROJECT=========================
Topic :-
	EVOLUTIONARY APROACH TO ROBOT PATH PLANNING
Group Number :-
	127
Made by :-
	Aditya Sharma 	B5	19103163
	Harshit Kawatra	B5	19103153
	Prabhat Ranjan	B5	19103183
Supervisor :-
	Dr. Parul Agarwal

====================================================================
Prerequisites:-
	Python
	Python packages:-
		pyfiglet, numpy, math, os, random, time	

Execution:-
	To run the project, open the main.py file in any code editor
	and click run.

Summary:-
	This project aims to address the Travelling Salesman Problem 
	(TSP) using a range of metaheuristic optimization algorithms. 
	The TSP is a widely known optimization problem that entails 
	finding the shortest route that visits all the given cities 
	and returns to the starting point. This project utilises a 
	set of popular metaheuristic algorithms, including Particle 
	Swarm Optimization (PSO), Genetic Algorithm (GA), Ant Colony 
	Optimization (ACO), Butterfly Optimization Algorithm (BOA), 
	Simulated Annealing, Hill Climbing, and Dynamic Programming.
