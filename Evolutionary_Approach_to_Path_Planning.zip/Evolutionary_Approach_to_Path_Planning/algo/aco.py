import numpy as np
from utils import pass_val

cities,distance_matrix = pass_val() 

n_cities = distance_matrix.shape[0]

# print("Distance matrix:")
# print(distance_matrix)

def aco_tsp(distance_matrix, n_ants=20, n_iterations=1000, alpha=1, beta=5, evaporation_rate=0.5, initial_pheromone=1):

    n_cities = distance_matrix.shape[0]
    pheromone = np.ones((n_cities, n_cities)) * initial_pheromone

    best_solution = None
    best_fitness = np.inf

    for iteration in range(n_iterations):

        ants = np.zeros((n_ants, n_cities), dtype=int)

        for ant in range(n_ants):
            visited_cities = set([0])
            current_city = 0

            for i in range(1, n_cities):
                unvisited_cities = set(range(n_cities)) - visited_cities
                unvisited_cities = list(unvisited_cities)

                probs = []
                for city in unvisited_cities:
                    pheromone_factor = pheromone[current_city, city] ** alpha
                    distance_factor = (1 / distance_matrix[current_city, city]) ** beta
                    prob = pheromone_factor * distance_factor
                    probs.append(prob)

                probs = np.array(probs)
                probs /= np.sum(probs)

                next_city = np.random.choice(unvisited_cities, p=probs)
                ants[ant, i] = next_city
                visited_cities.add(next_city)
                current_city = next_city

            ants[ant, -1] = 0

        for i in range(n_cities):
            for j in range(n_cities):
                if i != j:
                    pheromone[i, j] *= (1 - evaporation_rate)
                    for ant in range(n_ants):
                        ant_solution = ants[ant, :]
                        if (ant_solution[i] == j) and (ant_solution[j] == i):
                            pheromone[i, j] += (1 / distance_matrix[i, j])

        for ant in range(n_ants):
            ant_solution = ants[ant, :]
            dists = [distance_matrix[i, j] for i, j in zip(ant_solution[:-1], ant_solution[1:])]
            dists.append(distance_matrix[ant_solution[-1], ant_solution[0]])
            ant_fitness = np.sum(dists)

            if ant_fitness < best_fitness:
                best_fitness = ant_fitness
                best_solution = ant_solution

    return best_solution, best_fitness

best_solution_aco, best_fitness_aco = aco_tsp(distance_matrix, n_ants=20, n_iterations=1000)

print("Best solution found by ACO algorithm:", best_solution_aco)
print("Best fitness found by ACO algorithm:", best_fitness_aco)

