import numpy as np
import random
from utils import pass_val

max_generations = 100
num_butterflies = 20
alpha = 0.5  

# distances = np.random.rand(num_cities, num_cities)

cities, distance_matrix = pass_val()

num_cities = len(cities)

def bo_tsp(distance_matrix, n_butterflies=20, n_iterations=1000, alpha=0.1, beta=1):

    n_cities = distance_matrix.shape[0]
    butterflies = np.zeros((n_butterflies, n_cities), dtype=int)
    for i in range(n_butterflies):
        butterflies[i, :] = np.random.permutation(n_cities)

    best_solution = None
    best_fitness = np.inf

    for iteration in range(n_iterations):

        for i in range(n_butterflies):
            for j in range(n_cities):
                r1, r2, r3 = np.random.choice(n_butterflies, size=3, replace=False)
                new_position = butterflies[i, j] + alpha * (butterflies[r1, j] - butterflies[i, j]) + beta * (butterflies[r2, j] - butterflies[r3, j])
                new_position = int(np.round(new_position) % n_cities)
                butterflies[i, j] = new_position

        for i in range(n_butterflies):
            butterfly = butterflies[i, :]
            dists = [distance_matrix[butterfly[j], butterfly[j+1]] for j in range(n_cities-1)]
            dists.append(distance_matrix[butterfly[-1], butterfly[0]])
            butterfly_fitness = np.sum(dists)

            if butterfly_fitness < best_fitness:
                best_fitness = butterfly_fitness
                best_solution = butterfly

    return best_solution, best_fitness

best_solution_bo, best_fitness_bo = bo_tsp(distance_matrix, n_butterflies=20, n_iterations=1000)

print("Best solution found by BO algorithm:", best_solution_bo)
print("Best fitness found by BO algorithm:", best_fitness_bo)
