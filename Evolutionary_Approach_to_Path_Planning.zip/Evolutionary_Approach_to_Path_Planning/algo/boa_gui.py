import numpy as np
import random
import tkinter as tk

# Define the problem parameters
num_cities = 10
max_generations = 100
num_butterflies = 20
alpha = 0.5  # Probabilistic parameter

# Define the distance matrix
distances = np.random.rand(num_cities, num_cities)

# Define the Butterfly Optimization algorithm
def butterfly_optimization():
    # Initialize the population of butterflies
    population = np.zeros((num_butterflies, num_cities), dtype=int)
    for i in range(num_butterflies):
        population[i] = np.random.permutation(num_cities)
    
    # Define the fitness function
    def fitness(solution):
        # Check that the solution contains valid city indices
        if np.min(solution) < 0 or np.max(solution) >= num_cities:
            return 0.0
        
        total_distance = 0
        for i in range(num_cities):
            j = (i + 1) % num_cities
            total_distance += distances[solution[i], solution[j]]
        return 1 / total_distance if total_distance > 0 else 0.0
    
    # Iterate over the specified number of generations
    for generation in range(max_generations):
        # Evaluate the fitness of each butterfly
        fitness_values = np.array([fitness(solution) for solution in population])
        
        # Sort the butterflies by fitness
        sorted_indices = np.argsort(fitness_values)[::-1]
        population = population[sorted_indices]
        fitness_values = fitness_values[sorted_indices]
        
        # Update the global best solution
        global_best = population[0]
        
        # Update the position of each butterfly
        for i in range(num_butterflies):
            # Define the four reference butterflies
            r1, r2, r3, r4 = population[random.sample(range(num_butterflies), 4)]
            
            # Generate a new candidate solution
            candidate = population[i].copy()
            for j in range(num_cities):
                if random.random() < alpha:
                    # Apply the butterfly equation
                    candidate[j] += int((r1[j] - r2[j]) + (r3[j] - r4[j]))
            
            # Evaluate the fitness of the candidate solution
            candidate_fitness = fitness(candidate)
            
            # Update the current butterfly if the candidate is better
            if candidate_fitness > fitness_values[i]:
                population[i] = candidate
                fitness_values[i] = candidate_fitness
        
        # Update the GUI with the current best solution
        best_solution_label.config(text="Best solution: {}".format(global_best))
        window.update()
    
    return global_best

# Create the GUI window
window = tk.Tk()
window.title("Butterfly Optimization TSP Solver")

# Add a label for the best solution
best_solution_label = tk.Label(window, text="Best solution: ")
best_solution_label.pack()

# Add a button to start the solver
start_button = tk.Button(window, text="Start", command=butterfly_optimization)
start_button.pack()

# Start the GUI loop
window.mainloop()
