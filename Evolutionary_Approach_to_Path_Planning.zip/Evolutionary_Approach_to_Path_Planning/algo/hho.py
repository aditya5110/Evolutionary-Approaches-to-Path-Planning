import numpy as np
import random
from utils import pass_val

cities,distances = pass_val()

# Define the problem parameters
num_cities = len(cities)
max_iterations = 100
pop_size = 20
pa = 0.4
pm = 0.1

# Define the distance matrix
# distances = np.random.rand(num_cities, num_cities)

# Define the Harris Hawks Optimization algorithm
def hho_tsp():
    population = np.zeros((pop_size, num_cities), dtype=int)
    for i in range(pop_size):
        population[i] = np.random.permutation(num_cities)

    def fitness(solution):
        
        if np.min(solution) < 0 or np.max(solution) >= num_cities:
            return 0.0
        
        total_distance = 0
        for i in range(num_cities):
            j = (i + 1) % num_cities
            total_distance += distances[solution[i], solution[j]]
        return 1 / total_distance if total_distance > 0 else 0.0
    
    for iteration in range(max_iterations):
       
        fitness_values = np.array([fitness(solution) for solution in population])
       
        sorted_indices = np.argsort(fitness_values)[::-1]
        population = population[sorted_indices]
        fitness_values = fitness_values[sorted_indices]

        global_best = population[0]
 
        for i in range(pop_size):
 
            if random.random() < pa:
            
                new_solution = np.random.permutation(num_cities)
                
                new_fitness = fitness(new_solution)
   
                if new_fitness > fitness_values[i]:
                    population[i] = new_solution
                    fitness_values[i] = new_fitness
            
            else:
                hawk = population[i]
                num_local_searches = int(np.round(pm * num_cities))
                
                for j in range(num_local_searches):

                    candidate = hawk.copy()
                    a, b = random.sample(range(num_cities), 2)
                    candidate[a], candidate[b] = candidate[b], candidate[a]
                    
                    candidate_fitness = fitness(candidate)
                    
                    if candidate_fitness > fitness_values[i]:
                        population[i] = candidate
                        fitness_values[i] = candidate_fitness

        print("Iteration {}: Best solution: {}".format(iteration, global_best))
    
    return global_best

best_solution = hho_tsp()
print("Best solution:", best_solution)
