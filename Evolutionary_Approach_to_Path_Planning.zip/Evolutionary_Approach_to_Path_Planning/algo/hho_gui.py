import numpy as np
import random
import matplotlib.pyplot as plt

# Define the problem parameters
num_cities = 20
max_iterations = 100
pop_size = 20
pa = 0.4
pm = 0.1

# Define the distance matrix
distances = np.random.rand(num_cities, num_cities)

# Define the Harris Hawks Optimization algorithm
def hho_tsp():
    # Initialize the population of hawks
    population = np.zeros((pop_size, num_cities), dtype=int)
    for i in range(pop_size):
        population[i] = np.random.permutation(num_cities)
    
    # Define the fitness function
    def fitness(solution):
        # Check that the solution contains valid city indices
        if np.min(solution) < 0 or np.max(solution) >= num_cities:
            return 0.0
        
        total_distance = 0
        for i in range(num_cities):
            j = (i + 1) % num_cities
            total_distance += distances[solution[i], solution[j]]
        return 1 / total_distance if total_distance > 0 else 0.0
    
    # Iterate over the specified number of iterations
    for iteration in range(max_iterations):
        # Evaluate the fitness of each hawk
        fitness_values = np.array([fitness(solution) for solution in population])
        
        # Sort the hawks by fitness
        sorted_indices = np.argsort(fitness_values)[::-1]
        population = population[sorted_indices]
        fitness_values = fitness_values[sorted_indices]
        
        # Update the global best solution
        global_best = population[0]
        
        # Perform the different hunting stages
        for i in range(pop_size):
            # Perform the exploratory random search
            if random.random() < pa:
                # Generate a random solution
                new_solution = np.random.permutation(num_cities)
                
                # Evaluate the fitness of the new solution
                new_fitness = fitness(new_solution)
                
                # Replace the current solution if the new solution is better
                if new_fitness > fitness_values[i]:
                    population[i] = new_solution
                    fitness_values[i] = new_fitness
            
            else:
                # Perform the intensive local search
                hawk = population[i]
                num_local_searches = int(np.round(pm * num_cities))
                
                for j in range(num_local_searches):
                    # Generate a new candidate solution
                    candidate = hawk.copy()
                    a, b = random.sample(range(num_cities), 2)
                    candidate[a], candidate[b] = candidate[b], candidate[a]
                    
                    # Evaluate the fitness of the candidate solution
                    candidate_fitness = fitness(candidate)
                    
                    # Replace the current solution if the candidate is better
                    if candidate_fitness > fitness_values[i]:
                        population[i] = candidate
                        fitness_values[i] = candidate_fitness
        
        # Plot the current best solution
        plt.clf()
        plt.plot(distances[global_best, :][:, global_best])
        plt.title("Iteration {} - Best solution: {}".format(iteration, global_best))
        plt.xlabel("City index")
        plt.ylabel("Distance")
        plt.pause(0.01)
    
    return global_best

# Call the HHO TSP solver and print the best solution
best_solution = hho_tsp()
print("Best solution:", best_solution)

# Show the final plot
plt.show()
