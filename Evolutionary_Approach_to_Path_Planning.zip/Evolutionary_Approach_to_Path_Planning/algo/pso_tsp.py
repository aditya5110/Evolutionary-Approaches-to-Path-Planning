import numpy as np
from utils import pass_val

# def distance_matrix(cities):

#     n = cities.shape[0]
#     distance = np.zeros((n, n))
#     for i in range(n):
#         for j in range(n):
#             distance[i, j] = np.linalg.norm(cities[i] - cities[j])
#     return distance


def pso_tsp(cities, num_particles, num_iter, distance):

    n_cities = cities.shape[0]
    population = np.zeros((num_particles, n_cities), dtype=np.int32)
    for i in range(num_particles):
        population[i] = np.random.permutation(n_cities)

    velocity = np.zeros((num_particles, n_cities), dtype=np.int32)
    for i in range(num_particles):
        velocity[i] = np.random.permutation(n_cities)

    personal_best_position = population.copy()
    personal_best_fitness = np.zeros(num_particles)
    global_best_position = None
    global_best_fitness = np.inf

    # distances = distance_matrix(cities)
    distances = distance

    omega = 0.5
    c1 = 0.5
    c2 = 0.5

    for iter in range(num_iter):
        fitness_values = np.zeros(num_particles)
        for i, path in enumerate(population):
            fitness_values[i] = fitness(path, distances)
            if fitness_values[i] < personal_best_fitness[i]:
                personal_best_fitness[i] = fitness_values[i]
                personal_best_position[i] = path.copy()
            if fitness_values[i] < global_best_fitness:
                global_best_fitness = fitness_values[i]
                global_best_position = path.copy()

        for i in range(num_particles):
            r1 = np.random.rand(n_cities)
            r2 = np.random.rand(n_cities)
            velocity[i] = omega * velocity[i] \
                          + c1 * r1 * (personal_best_position[i] - population[i]) \
                          + c2 * r2 * (global_best_position - population[i])
            population[i] = np.argsort(velocity[i])
            population[i] = np.clip(population[i], a_min=0, a_max=n_cities - 1)

    return global_best_position, global_best_fitness


def fitness(path, distances):

    n_cities = len(path)
    total_distance = 0
    for i in range(-1, n_cities - 1):
        total_distance += distances[path[i], path[i + 1]]
    return total_distance

cities,dist = pass_val()
best_path, best_fitness = pso_tsp(cities, num_particles=50, num_iter=1000, distance= dist)
print("Best path:", best_path)
print("Best fitness:", best_fitness)
