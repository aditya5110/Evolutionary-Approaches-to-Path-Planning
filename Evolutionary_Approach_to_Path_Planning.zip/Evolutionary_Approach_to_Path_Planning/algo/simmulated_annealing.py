import numpy as np
import random
import math
from utils  import pass_val


cities, distance_matrix = pass_val()

n_cities = distance_matrix.shape[0]

solution = list(range(n_cities))
random.shuffle(solution)

T = 100
cooling_rate = 0.99

def objective_function(solution):
    total_distance = 0
    for i in range(n_cities - 1):
        total_distance += distance_matrix[solution[i], solution[i+1]]
    total_distance += distance_matrix[solution[-1], solution[0]]
    return total_distance

while T > 1e-8:

    new_solution = list(solution)
    i, j = random.sample(range(n_cities), 2)
    new_solution[i], new_solution[j] = new_solution[j], new_solution[i]

    E_new = objective_function(new_solution)
    E_current = objective_function(solution)

    p = math.exp(-(E_new - E_current) / T)
    if random.uniform(0, 1) < p:
        solution = new_solution

    T *= cooling_rate

total_distance = objective_function(solution)

print("Optimal tour:", solution)
print("Total distance:", total_distance)
