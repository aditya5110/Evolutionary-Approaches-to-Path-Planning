import numpy as np
import random

# city = np.array( [[0.73916358, 0.01230441],
#         [0.52456603, 0.71366511],
#         [0.93182473, 0.26474225],
#         [0.38261903, 0.39971819],
#         [0.9373667 , 0.94072954],
#         [0.49978126, 0.92522918],
#         [0.19005715, 0.39952972],
#         [0.90953185, 0.13877543],
#         [0.7409656 , 0.38659766],
#         [0.76433203, 0.43438144]])


def load():
     global city
     global distances
     city = np.loadtxt("C:\\Users\\harsh\\Desktop\\MAJOR II\\New folder\\algo\\cities.txt",dtype=float)
     distances = distance_mat(city)
def choice(val):
     if val == 1:
           change_input()

def distance_mat(cities):
        n = cities.shape[0]
        distance = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                distance[i, j] = np.linalg.norm(cities[i] - cities[j])
        return distance

def change_input():
      city = np.random.randint(1,50,size=(10, 2))
      np.savetxt("C:\\Users\\harsh\\Desktop\\MAJOR II\\New folder\\algo\\cities.txt",city)
      load()
      

#       txt = open("C:\\Users\\harsh\\Desktop\\MAJOR II\\New folder\\algo\\cities.txt","w")
#       txt.write(city)
#       txt.close()


def pass_val():
     return city,distances


city = np.loadtxt("C:\\Users\\harsh\\Desktop\\MAJOR II\\New folder\\algo\\cities.txt",dtype=float)
distances = distance_mat(city)
# print(city)