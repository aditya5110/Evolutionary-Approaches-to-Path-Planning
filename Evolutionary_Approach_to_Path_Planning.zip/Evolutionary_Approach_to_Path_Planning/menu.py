import pyfiglet as pf
import numpy as np
import math
import os
import random
import time
import algo.utils as utils

tic_pso,toc_pso, pso= 0,0,0
tic_ga,toc_ga, ga = 0,0,0
tic_hho, toc_hho, hho = 0,0,0
tic_hc, toc_hc, hc = 0,0,0
tic_boa,toc_boa, boa = 0,0,0 
tic_sa,toc_sa, sa = 0,0,0
tic_dp,toc_dp, dp = 0,0,0
tic_aco,toc_aco, aco = 0,0,0

def times():
    # return pso,ga,hc,dp,boa,hho,sa
    # print(pso,ga,hc,dp,boa,hho,sa)
    print("Time Taken by each algorithm to solve this problem:")
    print("1. Particle Swarm Optimization : ",pso)
    print("2. Genetic Algorithm : ", ga)
    print("3. Hill Climbing Algorithm : ", hc)
    print("4. Dynamic Programming Algorithm : ", dp)
    print("5. Butterfly Optimization Algorithm : ", boa)
    print("6. Harris-Hawk Optimization Algorithm : ", hho)
    print("7. Simmulated Annealing Algorithm : ", sa)
    print("8. Ant Colony Optimization Algorithm : ", aco)



def titlescreen():
    heading = pf.figlet_format("EVOLOUTIONARY APPROACH TO PATH PLANNING", font= "bubble", justify="center", width=60)
    members = pf.figlet_format("Members:", font= "digital", justify="right")
    harshit = pf.figlet_format("19103153 Harshit Kawatra B5", font= "digital", justify="right")
    aditya = pf.figlet_format("19103163 Aditya Sharma B5", font= "digital", justify="right")
    prabhat = pf.figlet_format("19103183 Prabhat Ranjan B6",font="digital",justify="right")
    print(heading)
    print(members)
    print(harshit)
    print(aditya)
    print(prabhat)
    x = input()
    

    

def menu(cities,distance):

    while True:
        os.system('cls')
        menu = pf.figlet_format("MENU", font= "digital", justify="center")
        print(menu)
        print("1. Particle Swarm Optimization")
        print("2. Genetic Algorithm")
        print("3. Hill Climbing Algorithm")
        print("4. Dynamic Programming Algorithm")
        print("5. Butterfly Optimization Algorithm")
        print("6. Harris-Hawk Optimization Algorithm")
        print("7. Simmulated Annealing Algorithm")
        print("8. Ant Colony Optimization Algorithm")
        print("9. Show Input Data")
        print("10. Change Input Data")
        print("11. Exit")
        

        inp = int(input("Enter your choice"))

        if inp == 1:
            global tic_pso
            tic_pso = time.time()
            os.system("python algo/pso_tsp.py")
            global toc_pso 
            toc_pso = time.time()
        if inp == 2:
            global tic_ga 
            tic_ga = time.time()
            os.system("python algo/tsp_genetic.py")
            global toc_ga 
            toc_ga = time.time()
        if inp == 3:
            global tic_hc 
            tic_hc = time.time()
            os.system("python algo/HillClimbing-TSP.py")
            global toc_hc 
            toc_hc = time.time()
        if inp == 4:
            global tic_dp 
            tic_dp = time.time()
            os.system("python algo/tsp_dp.py")
            global toc_dp
            toc_dp = time.time()
        if inp == 5:
            global tic_boa 
            tic_boa = time.time()
            os.system("python algo/boa.py")
            global toc_boa 
            toc_boa = time.time()
        if inp == 6:
            global tic_hho 
            tic_hho = time.time()
            os.system("python algo/hho.py")
            global toc_hho 
            toc_hho = time.time()
        if inp == 7:
            global tic_sa 
            tic_sa = time.time()
            os.system("python algo/simmulated_annealing.py")
            global toc_sa 
            toc_sa = time.time()
        if inp == 8:
            global tic_aco 
            tic_aco = time.time()
            os.system("python algo/aco.py")
            global toc_aco 
            toc_aco = time.time()
        if inp == 9:
            print("Input Cities Coordinates:")
            print(cities)
            print("\n\n Distance Matrix: ")
            print(distance)
            print("\n\n")
        if inp == 10:
            utils.choice(1)
            cities,distance = utils.pass_val()
            print("New Data:")
            print("Input Cities Coordinates:")
            print(cities)
            print("\n\n Distance Matrix: ")
            print(distance)
            print("\n\n")

        if inp == 11:
            break
        
        x = input()
            

if __name__ == "__main__":

    titlescreen()
    cities,dist = utils.pass_val()
    menu(cities,dist)
    pso = toc_pso - tic_pso
    ga = toc_ga - tic_ga
    hc = toc_hc - tic_hc
    dp = toc_dp - tic_dp
    boa = toc_boa - tic_boa
    hho = toc_hho - tic_hho
    sa = toc_sa - tic_sa
    aco = toc_aco - tic_aco
    times()


    



    
